//
//  CreateEventVC.swift
//  eventApp
//
//  Created by OSX on 5/25/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

class CreateEventVC: UIViewController{


    @IBOutlet weak var eventNameTextField: UITextField!
    @IBOutlet weak var dateAndTimeTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    
    let bag = DisposeBag()
    
    var memberLogic = MemberLogic()
    var eventsCrud = EventsCrud()
    
    var eventName = ""
    var eventDateAndTime = ""
    var eventLocation = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePicker.Mode.dateAndTime
        datePicker.addTarget(self, action:#selector(CreateEventVC.dateAndTimePickerValueChanged(sender:)), for: UIControl.Event.valueChanged)
        
        dateAndTimeTextField.inputView = datePicker
        
        eventNameTextField.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.eventName = text
                
            }).disposed(by: bag)
        locationTextField.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.eventLocation = text
               
            }).disposed(by: bag)
        dateAndTimeTextField.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.eventDateAndTime = text
               
            }).disposed(by: bag)
    }
    
    @IBAction func buCancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func buCreateEvent(_ sender: Any) {
        eventsCrud.create(url: "http://localhost:3000/events-create", title: eventName, location: eventLocation, time: eventDateAndTime)
 
        eventNameTextField.text = ""
        locationTextField.text = ""
        dateAndTimeTextField.text = ""
    }
}

extension CreateEventVC {
    @objc func dateAndTimePickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        
        
        formatter.dateStyle = DateFormatter.Style.medium
        formatter.timeStyle = DateFormatter.Style.none
        dateAndTimeTextField.text = formatter.string(from: sender.date)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
}


