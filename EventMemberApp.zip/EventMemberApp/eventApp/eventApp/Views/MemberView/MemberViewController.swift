//
//  MemberViewController.swift
//  eventApp
//
//  Created by OSX on 5/27/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

class MemberViewController: UIViewController {

    @IBOutlet weak var navItem: UINavigationItem!
    
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelGender: UILabel!
    @IBOutlet weak var labelBirthday: UILabel!
    @IBOutlet weak var labelInfo: UILabel!
    
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldGender: UITextField!
    @IBOutlet weak var textFieldBirthday: UITextField!
    @IBOutlet weak var textFieldInfo: UITextView!
    
    @IBOutlet weak var buEditOutlet: UIButton!
    @IBOutlet weak var buPostOutlet: UIButton!
    
    let bag = DisposeBag()
    let memberCrud = MembersCrud()
    let memberLogic = MemberLogic()
    
    let myPickerData = [String](arrayLiteral: "male", "female")
    var memberReceived : Member?
    var name = ""
    var gender = ""
    var birthday = ""
    var info = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let name = memberReceived?.name,
            let gender = memberReceived?.gender,
            let birthday = memberReceived?.date,
            let info = memberReceived?.info
        else {return}
        
        navItem.title = name
        labelName.text = name
        labelGender.text = gender
        labelBirthday.text = birthday
        labelInfo.text = info
        
        textFieldName.isHidden = true
        textFieldGender.isHidden = true
        textFieldBirthday.isHidden = true
        textFieldInfo.isHidden = true
        
        buPostOutlet.isHidden = true
        
        let genderPicker = UIPickerView()
        textFieldGender.inputView = genderPicker
        genderPicker.delegate = self
        
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePicker.Mode.date
        datePicker.addTarget(self, action:#selector(MemberViewController.datePickerValueChanged(sender:)), for: UIControl.Event.valueChanged)
        
        textFieldBirthday.inputView = datePicker
        
        
        textFieldName.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.name = text
            }).disposed(by: bag)
        
        textFieldGender.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.gender = text
            }).disposed(by: bag)
        
        textFieldBirthday.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.birthday = text
            }).disposed(by: bag)
        
        textFieldInfo.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.info = text
            }).disposed(by: bag)
  
    }

    @IBAction func buBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func buEdit(_ sender: Any) {
        labelName.isHidden = true
        labelGender.isHidden = true
        labelBirthday.isHidden = true
        labelInfo.isHidden = true
        
        textFieldName.isHidden = false
        textFieldGender.isHidden = false
        textFieldBirthday.isHidden = false
        textFieldInfo.isHidden = false
    
        buEditOutlet.isHidden = true
        buPostOutlet.isHidden = false

    }
    
    
    @IBAction func buPost(_ sender: Any) {
        
        buEditOutlet.isHidden = false
        buPostOutlet.isHidden = true
        
        labelName.isHidden = false
        labelGender.isHidden = false
        labelBirthday.isHidden = false
        labelInfo.isHidden = false
        
        textFieldName.isHidden = true
        textFieldGender.isHidden = true
        textFieldBirthday.isHidden = true
        textFieldInfo.isHidden = true
 
        
        
        
        textFieldName.text = ""
        textFieldGender.text = ""
        textFieldBirthday.text = ""
        textFieldInfo.text = ""
        
        labelName.text = ""
        labelBirthday.text = ""
        labelGender.text = ""
        labelInfo.text = ""
        
        guard let url = memberReceived?.url else {return}
        memberCrud.put(url: url, name: name, gender: gender, birthDay: birthday, info: info)
        memberLogic.crudObjects(url: "http://localhost:3000/members")
        
    }

}
extension MemberViewController {
    @objc func datePickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateStyle = DateFormatter.Style.medium
        formatter.timeStyle = DateFormatter.Style.none
        textFieldBirthday.text = formatter.string(from: sender.date)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
}
extension MemberViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return myPickerData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return myPickerData[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textFieldGender.text = myPickerData[row]
    }
    
    
    
}
