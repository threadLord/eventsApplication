//
//  EventsCell.swift
//  eventApp
//
//  Created by OSX on 5/22/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit

class EventsCell: UITableViewCell {

    
    @IBOutlet weak var labelTitle: UILabel!
    
    @IBOutlet weak var labelLocation: UILabel!
    
    @IBOutlet weak var labelTime: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
