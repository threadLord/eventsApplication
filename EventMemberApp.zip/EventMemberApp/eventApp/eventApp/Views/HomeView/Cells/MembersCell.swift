//
//  MembersCell.swift
//  eventApp
//
//  Created by OSX on 5/22/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit

class MembersCell: UITableViewCell {

    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var surnameLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
