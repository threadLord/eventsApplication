//
//  ViewController.swift
//  eventApp
//
//  Created by OSX on 5/22/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

class ViewController: UIViewController {

    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var segmentedController: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    var eventsLogic = EventLogic()
    var memberLogic = MemberLogic()
    
    var eventCrud = EventsCrud()
    var memberCrud = MembersCrud()
    
    
    var bag = DisposeBag()
 
    var eventToSend : Events?
    var memberToSend : Member?
    
    
    
    
    var p = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate=self
        tableView.dataSource=self
        registeCells1()
        registeCells2()
        
       memberLogic.crudObjects(url: "http://localhost:3000/members")
        eventsLogic.crudObjects(url: "http://localhost:3000/events")
        
        memberLogic.memberRepoVar.asObservable()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] values in
                self?.tableView.reloadData()
            }).disposed(by: memberLogic.bag)
        
        eventsLogic.eventRepoVar.asObservable()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] values in
                self?.tableView.reloadData()
            }).disposed(by: eventsLogic.bag)
            
        print(segmentedController.selectedSegmentIndex)
        eventsLogic.sessionError
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { errorString in

                print("is main thread: \(Thread.isMainThread)")
                
                let alert = UIAlertController(title: "Error", message: "Events Can not be downloaded.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    self?.eventsLogic.crudObjects(url: "http://localhost:3000/events")
                }))
                alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }).disposed(by: eventsLogic.bag)
        memberLogic.sessionError
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { errorString in
                print("error String: \(errorString)")
                let alert = UIAlertController(title: "Error", message: "Members Can not be downloaded.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    self?.memberLogic.crudObjects(url: "http://localhost:3000/members")
                }))
                alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
                self.present(alert, animated: true)
            }).disposed(by: memberLogic.bag)

        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        eventsLogic.dataTask?.cancel()
        eventsLogic.defaultSession.invalidateAndCancel()

        memberLogic.dataTask?.cancel()
        memberLogic.defaultSession.invalidateAndCancel()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if p == 0 {
            if segue.identifier == "toEvent" {
                if let dest = segue.destination as? EventViewController {
                    guard let eventToSend = eventToSend else {return}
                    dest.eventReceived = eventToSend
                }
            }
        }
        if p == 1 {
            if segue.identifier == "toMember" {
                if let dest = segue.destination as? MemberViewController {
                    guard let memberToSend = memberToSend else {return}
                    dest.memberReceived = memberToSend
                }
            }
        }
    }
    
    
    @IBAction func buSegmented(_ sender: UISegmentedControl) {
        p = sender.selectedSegmentIndex
        tableView.reloadData()
    }
    
    @IBAction func buAdd(_ sender: Any) {
        if p == 0 {
            performSegue(withIdentifier: "toNewEvent", sender: Any?.self)
        } else {
            performSegue(withIdentifier: "toNewMember", sender: Any?.self)
        }
    }
}
extension ViewController {
    
    func registeCells1() {
        let nibName = UINib(nibName: "EventsCell", bundle: nil)
        tableView.register(nibName, forCellReuseIdentifier: "eventsCell")
    }
    func registeCells2() {
        let nibName = UINib(nibName: "MembersCell", bundle: nil)
        tableView.register(nibName, forCellReuseIdentifier: "membersCell")
        
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if p == 0 {
            return eventsLogic.eventRepoVar.value.count
        } else {
            return memberLogic.memberRepoVar.value.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if p == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "eventsCell", for: indexPath) as! EventsCell
            cell.labelTitle.text = eventsLogic.eventRepoVar.value[indexPath.row].title
            cell.labelLocation.text = eventsLogic.eventRepoVar.value[indexPath.row].location
            cell.labelTime.text = eventsLogic.eventRepoVar.value[indexPath.row].time

            return cell
        } else {
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "membersCell", for: indexPath) as! MembersCell
        cell2.nameLabel.text = memberLogic.memberRepoVar.value[indexPath.row].name
        cell2.imageCell.image = UIImage.init(named: "member")
        
        return cell2
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if p == 0 {
            eventToSend = eventsLogic.eventRepoVar.value[indexPath.row]
            if eventToSend != nil {
                performSegue(withIdentifier: "toEvent", sender: Any?.self)
            }
        }
        if p == 1 {
            memberToSend = memberLogic.memberRepoVar.value[indexPath.row]
            if memberToSend != nil {
                performSegue(withIdentifier: "toMember", sender: Any?.self)
            }
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if p == 0 {
                if let url = eventsLogic.eventRepoVar.value[indexPath.row].url {
                    eventCrud.delete(url: url)
                    eventsLogic.eventRepoVar.value.remove(at: indexPath.row)
  
                }
            }
            if p == 1 {
                if let url = memberLogic.memberRepoVar.value[indexPath.row].url {
                    memberCrud.delete(url: url)
                    memberLogic.memberRepoVar.value.remove(at: indexPath.row)
                }
            }
        }
    }
    

}

