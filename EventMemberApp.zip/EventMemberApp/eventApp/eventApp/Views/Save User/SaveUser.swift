//
//  SaveUser.swift
//  eventApp
//
//  Created by OSX on 5/23/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

class SaveUser: UIViewController {


    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var genderTextField: UITextField!
    @IBOutlet weak var Birthday: UITextField!
    @IBOutlet weak var infoText: UITextView!
    
    var membersCrud = MembersCrud()
    
    let myPickerData = [String](arrayLiteral: "male", "female")
    var name = ""
    var gender = ""
    var birthday = ""
    var info = ""
    
    let bag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePicker.Mode.date
        datePicker.addTarget(self, action:#selector(SaveUser.datePickerValueChanged(sender:)), for: UIControl.Event.valueChanged)

        Birthday.inputView = datePicker
        
        
        
        
        let genderPicker = UIPickerView()
        genderTextField.inputView = genderPicker
        genderPicker.delegate = self
        
        
        
        nameTextField.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.name = text
            }).disposed(by: bag)
        
        genderTextField.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.gender = text
            }).disposed(by: bag)
        
        Birthday.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.birthday = text
            }).disposed(by: bag)

        infoText.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.info = text
            }).disposed(by: bag)
    }
    
    
    @IBAction func buSaveUser(_ sender: UIButton) {
        
        membersCrud.create(url: "http://127.0.0.1:3000/members-create", name: name, gender: gender, birthDay: birthday, info: info)
        
        nameTextField.text = ""
        genderTextField.text = ""
        Birthday.text = ""
        infoText.text = ""
    }
    

    
    
    @IBAction func buCancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}


extension SaveUser {
   @objc func datePickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateStyle = DateFormatter.Style.medium
        formatter.timeStyle = DateFormatter.Style.none
        Birthday.text = formatter.string(from: sender.date)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    
}
extension SaveUser: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return myPickerData.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return myPickerData[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        genderTextField.text = myPickerData[row]
    }
}


