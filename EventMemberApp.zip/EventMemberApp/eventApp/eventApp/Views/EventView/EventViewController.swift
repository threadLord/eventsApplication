//
//  EventViewController.swift
//  eventApp
//
//  Created by OSX on 5/27/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

class EventViewController: UIViewController {

    @IBOutlet weak var buPostOutlet: UIButton!
    
    @IBOutlet weak var BuEditOutlet: UIButton!
    
    @IBOutlet weak var segmetedContr: UISegmentedControl!
    
    @IBOutlet weak var imageEvent: UIImageView!
    
    @IBOutlet weak var labelEventTitle: UILabel!
    @IBOutlet weak var textFieldTitle: UITextField!
    @IBOutlet weak var labelLocation: UILabel!
    @IBOutlet weak var textFieldLocation: UITextField!
    @IBOutlet weak var labelTime: UILabel!
    @IBOutlet weak var textFieldTime: UITextField!
    
    @IBOutlet weak var navItem: UINavigationItem!
    
    @IBOutlet weak var tableViewMembers: UITableView!
    
    let bag = DisposeBag()
    
    
    
    var eventReceived : Events?
    var memberLogic = MemberLogic()
    var arrayToAdd : [Member] = []
    
    
    var eventsCrud = EventsCrud()
    var memberCrud = MembersCrud()
    
    var eventName = ""
    var eventTimeAndDate = ""
    var eventLocation = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let navName = eventReceived?.title,
            let evLabelTitle = eventReceived?.title,
            let evLabelTime = eventReceived?.time,
            let evLabelLocation = eventReceived?.location
        else {return}

        navItem.title = navName
        
        labelEventTitle.text = evLabelTitle
        labelTime.text = evLabelTime
        labelLocation.text = evLabelLocation
        
        textFieldTime.isHidden = true
        textFieldTitle.isHidden = true
        textFieldLocation.isHidden = true
        
        tableViewMembers.delegate=self
        tableViewMembers.dataSource=self
        
        buPostOutlet.isHidden = true
        
        memberLogic.crudObjects(url: "http://localhost:3000/members")
        
        memberLogic.memberRepoVar.asObservable()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] values in
                print("value")
                
                for value in values{
                    print("value name: \(value.name)")
                }
                self?.tableViewMembers.reloadData()
            }).disposed(by: memberLogic.bag)
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePicker.Mode.dateAndTime
       
        datePicker.addTarget(self, action:#selector(EventViewController.dateAndTimePickerValueChanged(sender:)), for: UIControl.Event.valueChanged)
        
        textFieldTime.inputView = datePicker
        

        
        textFieldTitle.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.eventName = text
                print("name is \(self?.eventName)")
            }).disposed(by: bag)
        textFieldLocation.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.eventLocation = text
                print("name is \(self?.eventLocation)")
            }).disposed(by: bag)
        textFieldTime.rx.text
            .filter { ($0 ?? "").count >= 3 }
            .throttle(0.5, scheduler: MainScheduler.instance)
            .subscribe(onNext: { [weak self] text in
                guard let text = text else {return}
                self?.eventTimeAndDate = text
                print("birthday is \(self?.eventTimeAndDate)")
            }).disposed(by: bag)
    }
    

    @IBAction func buSegmentedContr(_ sender: Any) {
        tableViewMembers.reloadData()
        
    }
    
    
    @IBAction func buEdit(_ sender: Any) {
        labelEventTitle.isHidden = true
        labelTime.isHidden = true
        labelLocation.isHidden = true
        
        textFieldTime.isHidden = false
        textFieldTitle.isHidden = false
        textFieldLocation.isHidden = false
        

        BuEditOutlet.isHidden = true
        buPostOutlet.isHidden = false
    }
    
    @IBAction func buBack(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func buPost(_ sender: Any) {
        buPostOutlet.isHidden = true
        BuEditOutlet.isHidden = false
        
        
        labelEventTitle.isHidden = false
        labelTime.isHidden = false
        labelLocation.isHidden = false
        
        textFieldTime.isHidden = true
        textFieldTitle.isHidden = true
        textFieldLocation.isHidden = true
        
        guard let url = eventReceived?.url,
            let title = textFieldTitle.text,
            let location = textFieldLocation.text,
            let time = textFieldTime.text
        else {return}
        if let event = eventReceived {
            
            eventsCrud.patch(url: url, title: title, location: location, time: time, event: event)
            
        }
        
        textFieldTitle.text = ""
        textFieldTime.text = ""
        textFieldLocation.text = ""
    }
}

extension EventViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let numberOfMembers = eventReceived?.member?.count else {return 0}
        switch segmetedContr.selectedSegmentIndex {
        case 0:
            return memberLogic.memberRepoVar.value.count
        case 1:
            return numberOfMembers
        default:
            break
        }
        
        return memberLogic.memberRepoVar.value.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewMembers.dequeueReusableCell(withIdentifier: "eventCell", for: indexPath)
        switch segmetedContr.selectedSegmentIndex {
            
        case 0:
            cell.textLabel?.text = memberLogic.memberRepoVar.value[indexPath.row].name
        case 1:
            let name = eventReceived?.member?[indexPath.row].name
            cell.textLabel?.text = name
        default:
            break
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("segmented Controller: \(segmetedContr.selectedSegmentIndex)")
        
        switch self.segmetedContr.selectedSegmentIndex {
        case 0:
           print(indexPath.row)
           let memberRepoVarIndexPath = memberLogic.memberRepoVar.value[indexPath.row]
           
           let nameAtIndexPath = memberLogic.memberRepoVar.value[indexPath.row].name
           
           guard let eventMembers = eventReceived?.member else {return}
           
           if eventMembers.count == 0 {
                eventReceived?.member?.append(memberRepoVarIndexPath)
           }
           for memberInEvent in eventMembers {
            guard let name = memberInEvent.name else {return}
            if nameAtIndexPath != name {
                eventReceived?.member?.append(memberRepoVarIndexPath)
                
                break
            }
           }
        case 1:
            print(indexPath.row)
            
            guard let indexPathForMember = eventReceived?.member?[indexPath.row] else {return}
            print(indexPathForMember)
        default:
            break
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            switch segmetedContr.selectedSegmentIndex {
            case 0:
                if let url = memberLogic.memberRepoVar.value[indexPath.row].url {
                    memberCrud.delete(url: url)
                    memberLogic.memberRepoVar.value.remove(at: indexPath.row)
                }
            case 1:
                eventReceived?.member?.remove(at: indexPath.row)
                tableView.reloadData()
            default:
                break
            }
        }
    }
}
        


extension EventViewController {
    @objc func dateAndTimePickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        
        
        formatter.dateStyle = DateFormatter.Style.medium
        formatter.timeStyle = DateFormatter.Style.none
        textFieldTime.text = formatter.string(from: sender.date)
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
}
