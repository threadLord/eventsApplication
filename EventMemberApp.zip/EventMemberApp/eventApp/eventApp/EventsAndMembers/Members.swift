//
//  Members.swift
//  eventApp
//
//  Created by OSX on 5/25/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class MemberLogic : Fetch {
   
    
    var bag = DisposeBag()
    
    var memberRepoVar = Variable<[Member]>([])
    
    public var sessionError : Observable<String> {
        return errorVar.asObservable()
    }
    fileprivate var errorVar = Variable("")
    typealias Object = Member
    let defaultSession = URLSession(configuration: .default)
    var dataTask: URLSessionDataTask?
    
    func crudObjects(url:String?){
       
        dataTask?.cancel()
        if let url = url {
            if let initializerdURl = URL.init(string: url) {
                dataTask = defaultSession.dataTask(with: initializerdURl, completionHandler: { [weak self] (data, response, error) in
                    defer { self?.dataTask = nil }
                    if let error = error {
                        self?.errorVar.value = error.localizedDescription
                        print(error.localizedDescription)
                    } else if let data = data,
                        let response = response as? HTTPURLResponse,
                        response.statusCode == 200 {
                        if let newObj = try? JSONDecoder().decode([Member].self, from: data) {
                            self?.memberRepoVar.value = newObj
                        }
                    }
                })
                dataTask?.resume()
            }
        }
    }
}


