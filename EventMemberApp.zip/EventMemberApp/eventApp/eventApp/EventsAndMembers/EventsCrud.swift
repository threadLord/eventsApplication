//
//  EventsCrud.swift
//  eventApp
//
//  Created by OSX on 5/25/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation
import Alamofire
import RxAlamofire
import UIKit

class EventsCrud : UIViewController, CRUD {
    let domainUrl = "http://localhost:3000/"
    
    func create(url: String?, title : String?,location : String?, time : String?){
        guard let url = url,
        let title = title,
        let location = location,
        let time = time
            else {return}
        let parameters : Parameters = [
            "title" : title,
            "location" : location,
            "time" : time,
            "url" : domainUrl + "events-first"
        ]
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default)
            .responseJSON { response in
                guard response.result.error == nil else {
                    self.presentAlert(title: "Error", description: "Failed to create New Event")
                    return
                }
                guard let json = response.result.value as? [String: Any] else {
                    print("didn't get object as JSON from API")
                    if let error = response.result.error {
                        print("Error: \(error)")
                    }
                    return
                }
                guard let eventTitle = json["title"] as? String else {
                    return
                }
                self.presentAlert(title: "Success", description: "New Event Created")
        }
    }

    func delete(url: String?){
        guard let url = url else {return}
        Alamofire.request(url, method: .delete)
          .responseJSON { response in
            guard response.result.error == nil else {
                self.presentAlert(title: "Error", description: "Failed to delete Event")
                if let error = response.result.error {
                    print(error)
                }
                return
            }
            
            self.presentAlert(title: "Succes", description: "Object Deleted Successfully")
        }
    }
    
    func patch(url: String?, title : String?,location : String?, time : String?, event: Events?){
        guard let url = url else {return}
        guard let title = title else {return}
        guard let location = location else {return}
        guard let time = time else {return}
        
        
        guard let initializedURL = URL.init(string: url) else {return}
        var request = URLRequest(url: initializedURL)
        
        request.httpMethod = "PUT"

        guard var eventVar = event else {return}
        eventVar.title = title
        eventVar.location = location
        eventVar.time = time
        
        request.httpBody = try? JSONEncoder().encode(eventVar)
        
        Alamofire.request(request)
            .responseJSON { response in
                switch response.result {
                
                case .success(_):
                    
                self.presentAlert(title: "Succes", description: "Successfuly Updated Object")
                case .failure(_):
                    
                    self.presentAlert(title: "Error", description: "Failed to update an object")
                }
                if let data = response.data, let responseString = String(data: data, encoding: .utf8) {
                    print(responseString)
                }
    }
}

}


