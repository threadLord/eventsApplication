//
//  MembersCrud.swift
//  eventApp
//
//  Created by OSX on 5/25/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation
import Alamofire
import RxAlamofire
import UIKit

class MembersCrud : UIViewController, CRUD {
    
    let domainUrl = "http://localhost:3000/"
    
    func create(url: String?, name: String?, gender: String?, birthDay: String?, info: String?) {
        guard let url = url,
            let name = name,
            let gender = gender,
            let birthDay = birthDay,
            let info = info
            else {return}
        
        let parameters: Parameters = [
            
            "name": name,
            "gender": gender,
            "date": birthDay,
            "info": info,
            "url" : domainUrl + "members-first"
            
        ]
            Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default)
                .responseJSON { response in
                    guard response.result.error == nil else {
                        self.presentAlert(title: "Error", description: "Failed To Create Member")
                        print("error calling POST on members-create")
                        print(response.result.error!)
                        return
                    }
                    
                    guard let json = response.result.value as? [String: Any] else {
                        print("didn't get object as JSON from API")
                        if let error = response.result.error {
                            print("Error: \(error)")
                        }
                        return
                    }
                    guard let name = json["name"] as? String else {
                        print("Could not get id number from JSON")
                        return
                    }
                    print("Created user with name: \(name)")
            }
        }

    func put(url: String?, name: String?, gender: String?, birthDay: String?, info: String?) {
        guard let url = url,
            let name = name,
            let gender = gender,
            let birthDay = birthDay,
            let info = info
            else {return}
        
        let parameters: Parameters = [
            
            "name": name,
            "gender": gender,
            "date": birthDay,
            "info": info,
            "url" : url
        ]
        Alamofire.request(url, method: .put, parameters: parameters, encoding: JSONEncoding.default)
            .responseJSON { response in
                guard response.result.error == nil else {
                    self.presentAlert(title: "Error", description: "Failed To Update Member")
                    print("error calling POST on members-create")
                    print(response.result.error!)
                    return
                }
                self.presentAlert(title: "Success", description: "Member updated")
                
                guard let json = response.result.value as? [String: Any] else {
                    print("didn't get object as JSON from API")
                    if let error = response.result.error {
                        print("Error: \(error)")
                    }
                    return
                }
                guard let name = json["name"] as? String else {
                    print("Could not get id number from JSON")
                    return
                }
                print("Created user with name: \(name)")
        }
    }
    func delete(url: String?){
        guard let url = url else {return}
        Alamofire.request(url, method: .delete)
            .responseJSON { response in
                guard response.result.error == nil else {
                    print("error on delete")
                    
                    self.presentAlert(title: "Error", description: "Failed to delete Event")
                    
                    if let error = response.result.error {
                        print("Error: \(error)")
                    }
                    return
                }
                print("DELETE ok")
                self.presentAlert(title: "Succes", description: "Object Deleted Successfully")
        }
        
    }
    
}
