import UIKit
import Foundation
import Alamofire
import RxSwift
import RxCocoa
import RxAlamofire
enum error : Error {
    case BackendError
    
    
}


struct Todo : Codable {
    var userId : Int
    var id : Int
    var title: String
    var completed : Bool
    
}


extension JSONDecoder {

    func decodeResponse<T: Decodable>(_ type: T.Type, from response: DataResponse<Data>) -> Result<T> {
        guard response.error == nil else {
            print(response.error!)
            return .failure(response.error!)
        }

        guard let responseData = response.data else {
            print("didn't get any data from API")
            return .failure(error.BackendError)

        }

        do {
            let item = try decode(T.self, from: responseData)
            return .success(item)
        } catch {
            print("error trying to decode response")
            print(error)
            return .failure(error)
        }
    }
}
//
//
//
//Alamofire.request("https://jsonplaceholder.typicode.com/todos/")
//    .responseData { response in
//        let decoder = JSONDecoder()
//        let todo: Result<Todo> = decoder.decodeResponse(Todo.self, from: response)
//
//        print(todo)
//}


func download(completionHandler: ([Todo])->(Void)) {
    
    Alamofire.request("https://jsonplaceholder.typicode.com/todos/")
        .responseData { data in
            let decoder = JSONDecoder()
            let todo: Result<Todo> = decoder.decodeResponse(Todo.self, from: data)
            print(todo)
    }
    
    
}




