import Foundation


struct Events : Codable {
    var title : String?
    var location : String?
    var time : String?
    var lat : Double?
    var lon : Double?
    var member : [Member]?
    
}

struct Member : Codable {
    var name : String?
    var gender : String?
    var date : String?
    var info : String?
}




