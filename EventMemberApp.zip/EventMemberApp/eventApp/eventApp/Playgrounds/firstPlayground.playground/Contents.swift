//: A UIKit based Playground for presenting user interface
import Foundation
import UIKit
import PlaygroundSupport
import RxSwift
import Alamofire
import RxAlamofire

struct Events : Codable {
    var title : String?
    var location : String?
    var time : String?
    var lat : Double?
    var lon : Double?
    var member : [Member]?
    
}

struct Member : Codable {
    var name : String?
    var gender : String?
    var date : String?
    var info : String?
}



let bag = DisposeBag()
let parameters: Parameters = [
    "foo": "",
    "baz": "",
    "qux": ""
]


//Alamofire.request("http://127.0.0.1:3000/members", method: .post, parameters: parameters, encoding: JSONEncoding.default)

let stringURL = "http://127.0.0.1:3000/members"
let session = URLSession.shared


func requestMembers() {
    var objects = [Member]()
    
    var dataFor = Data()
    _ = request(.get, stringURL)
        .validate(statusCode: 200..<300)
        .validate(contentType: ["application/json"])
        .responseJSON()
//        .responseData()
        .observeOn(MainScheduler.instance)
        //        .subscribe { print($0)}
    
}

requestMembers()
    






class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "Hello World!"
        label.textColor = .black
        
        view.addSubview(label)
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
