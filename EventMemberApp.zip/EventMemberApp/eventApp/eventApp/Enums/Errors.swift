//
//  Errors.swift
//  eventApp
//
//  Created by OSX on 5/22/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation

enum Errors : Error {
    case badRequest
    case NoMembersToDisplay
    case NoEvents
}
