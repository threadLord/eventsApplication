//
//  Alert.swift
//  eventApp
//
//  Created by OSX on 5/28/19.
//  Copyright © 2019 OSX. All rights reserved.
//
import UIKit
import Foundation
import Alamofire

extension UIViewController {
    private func presentViewController(alert: UIAlertController, animated flag: Bool, completion: (() -> Void)?) -> Void {
        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: flag, completion: completion)
    }
    func presentAlert(title: String?, description: String?) {
        guard let title = title else {return}
        guard let description = description else {return}
        let alert = UIAlertController(title: title, message: description, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "O.K.", style: .cancel, handler: nil))
        presentViewController(alert: alert, animated: true, completion: nil)
    }
}
