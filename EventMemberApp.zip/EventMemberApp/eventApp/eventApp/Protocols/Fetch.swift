//
//  Fetch.swift
//  eventApp
//
//  Created by OSX on 5/25/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation

protocol Fetch {
    
    func crudObjects(url:String?)
}

extension Fetch {
    
    

    
}
