//
//  CRUD.swift
//  eventApp
//
//  Created by OSX on 5/24/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation
protocol CRUD {}
extension CRUD {
    func create(url: String?){}
    func put(url: String?){}
    func delete(url: String?){}
    func patch(url: String?){}
}


