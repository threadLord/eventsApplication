//
//  Member.swift
//  eventApp
//
//  Created by OSX on 5/26/19.
//  Copyright © 2019 OSX. All rights reserved.
//

import Foundation

struct Member : Codable {
    var name : String?
    var gender : String?
    var date : String?
    var info : String?
    var url : String?
}
